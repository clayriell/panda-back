const prisma = require("../config/db")

module.exports = {
    
}